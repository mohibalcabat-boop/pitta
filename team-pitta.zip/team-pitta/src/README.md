# Team Pitta · NASA Hackathon

Interactive Earth-systems explorer by Mahir Amer and Mohammed Alaa.

- `index.html` page shell
- `css/style.css` styles (light and dark themes)
- `data/topics.js`, `data/more.js` all section text and illustrations
- `js/app.js` accordion, albedo lab, counters, scroll-spy, theme toggle

Open `index.html` directly or serve with GitHub Pages. Add a topic with `add('water',[['Title','Text']])` in `data/more.js`.
