# Builds a single self-contained dist/index.html (for hosts that need one file)
import re,os
os.makedirs("dist",exist_ok=True)
h=open("index.html").read()
h=h.replace('<link rel="stylesheet" href="css/style.css">',"<style>"+open("css/style.css").read()+"</style>")
js="\n".join(open(f).read() for f in ["data/topics.js","data/more.js","js/app.js"])
h=re.sub(r'<script src="data/topics.js"></script>.*?<script src="js/app.js"></script>',lambda m:"<script>"+js+"</script>",h,flags=re.S)
open("dist/index.html","w").write(h)
