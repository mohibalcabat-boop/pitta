const add=(id,items)=>T.find(t=>t.id===id).items.push(...items);
S.earth='<svg viewBox="0 0 800 300"><rect width="800" height="300" fill="#0b1d33"/><g fill="#fff" opacity=".7"><circle cx="60" cy="40" r="2"/><circle cx="300" cy="30" r="2"/><circle cx="700" cy="60" r="2"/><circle cx="500" cy="270" r="2"/></g><circle cx="400" cy="150" r="100" fill="#2c8fb5"/><path d="M340 110q30-24 54 0t-10 36-44 0zM410 160q34-14 50 14t-24 36z" fill="#6fbf73"/><ellipse cx="400" cy="150" rx="190" ry="50" fill="none" stroke="#9fe0ef" stroke-opacity=".5" stroke-dasharray="6 8"/></svg>';
S.sun='<svg viewBox="0 0 800 300"><rect width="800" height="300" fill="#07122a"/><circle cx="90" cy="150" r="70" fill="#ffb02e"/><path d="M170 120h300M170 150h300M170 180h300" stroke="#ffb02e" stroke-width="4" opacity=".5"/><circle cx="600" cy="150" r="80" fill="#2c8fb5"/><path d="M520 150a80 80 0 0 1 160 0" fill="none" stroke="#5be3a0" stroke-width="8" opacity=".8"/><path d="M500 80q-40 70 0 140" fill="none" stroke="#9fe0ef" stroke-width="4"/></svg>';
S.people='<svg viewBox="0 0 800 300"><rect width="800" height="300" fill="#dbe9f3"/><g fill="#5a7a96"><rect x="80" y="120" width="70" height="180"/><rect x="170" y="70" width="80" height="230"/><rect x="270" y="140" width="60" height="160"/><rect x="480" y="100" width="90" height="200"/><rect x="590" y="150" width="70" height="150"/></g><path d="M0 280h800v20H0z" fill="#4c9a58"/><g fill="#ffd36b"><rect x="190" y="100" width="12" height="12"/><rect x="215" y="140" width="12" height="12"/><rect x="505" y="130" width="12" height="12"/></g></svg>';

T.unshift({id:'earth',nav:'Earth science',title:'The map of Earth science',lead:'Earth science studies the planet’s structure, materials, processes and history. It has four main branches, linked by many related fields.',cap:'Four branches, one planet.',items:[
['Geology: the solid Earth','Geology studies rocks, minerals and landforms. Its fields include mineralogy, petrology, structural geology, volcanology, seismology, paleontology, stratigraphy, geomorphology and economic geology (ores, oil, gas and coal).'],
['Oceanography: the water bodies','Physical oceanography covers currents, waves and tides; chemical studies salinity; biological studies marine life; and marine geology studies the seafloor, trenches and ridges.'],
['Meteorology and climatology: the atmosphere','Meteorology handles short-term weather, storms and forecasts. Climatology studies long-term patterns and change. Atmospheric chemistry covers gases, ozone and air pollution.'],
['Astronomy and planetary science: Earth in space','This branch covers seasons, day and night and the Moon’s effect on tides, and compares Earth with other planets to learn how planets form and evolve.'],
['Why connect them?','Water, ice, life, air and rock constantly exchange energy and matter. Understanding one sphere means following its links to the others.']]});

add('water',[
['Global water use','UN figures show water use is growing about twice as fast as population. Groundwater is falling where irrigation outpaces recharge, and many rivers and lakes cross borders, so satellite data helps countries share one picture.'],
['Sediment','Sediment is loose particles from eroded rock, moved by rivers, wind, floods and storms. It can refresh farmland, but too much clogs reservoirs and contaminated sediment can poison wildlife.'],
['Estuaries','Estuaries are where river water meets the sea, like the Chesapeake Bay. They are highly productive habitats that filter pollutants and absorb floods and storm surges.'],
['Flood trends','US floods have grown in the Northeast and Midwest and eased in the Rockies and West, matching changes in heavy rainfall. New England has seen more frequent floods since the 1940s.']]);
add('ice',[
['Why ice and snow matter','Bright snow and ice have high albedo and reflect sunlight. As they shrink, more heat is absorbed. Their runoff also sets river timing and flood risk for billions of people.'],
['What NASA measures','Satellites track how much polar ice is melting, how dust and soot darken snow, and how permafrost loss could release stored carbon.'],
['Glacier mass balance','Mass balance is a glacier’s yearly net gain or loss. Snowfall adds mass; melting and calving remove it. It shows how much fresh water ice can supply and how much it adds to sea level.'],
['Lake ice turnover','Cold air cools the surface water until it sinks and pushes warmer water up. Once the surface freezes, the ice insulates the lake. Freeze and melt dates are key climate indicators.'],
['Ice thickness','Ice ranges from a few sheets of paper to over 20 meters thick. Thickness informs safe routes, animal behavior and links to climate and sea level.'],
['Ice age stages','Ocean ice is new under 10 cm, young at 10 to 30 cm, first-year above 30 cm, and multiyear once it survives a summer, usually 2 to 4 meters thick.']]);
add('ocean',[
['Ocean overview','The ocean holds about 97% of Earth’s water. NASA data capture circulation, winds, heat exchange, salinity, sea surface temperature and water quality.'],
['Surface topography','Altimeters time microwave pulses bounced off the sea to find its height above the geoid. This reveals currents and tides and helps forecast El Niño and La Niña.'],
['Sea level indicator','Sea level has risen about eight inches since 1880 and the rate is accelerating. It is a key climate indicator beyond temperature.'],
['Tsunamis','Earthquakes and eruptions push water into waves that can exceed 500 mph in the open sea. The 2004 Indian Ocean tsunami caused about 227,000 deaths. Satellites measure wave height and ground movement.'],
['Coastal impacts','Rising seas flood wetlands, erode shores, push salt water into aquifers and leave infrastructure more exposed to storms.']]);
add('life',[
['Biomes','Forest, grassland, desert, aquatic and tundra biomes are shaped by vegetation, soil, climate and wildlife. Species richness keeps ecosystems productive and stable.'],
['Terrestrial ecosystems','Land communities of plants and animals are a major NASA focus, covering hydrology, forestry, topography and wildfire, and they teach us how other worlds work.'],
['Biogeochemistry','This field studies how carbon, nitrogen and phosphorus cycle through air, water, ice, life and rock.'],
['Carbon flux','Carbon flux is the rate and direction of carbon moving between oceans, air, land and living things, from natural exchanges to urban fossil-fuel emissions.'],
['Why carbon matters','Carbon is in all life, CO2 shapes Earth’s heat balance, plants need it in soil and the ocean circulates it through currents and upwelling.'],
['Why biodiversity matters','Diverse ecosystems recycle nutrients, filter pollution, protect water supplies, trap carbon and supply medicines.']]);
add('air',[
['Atmosphere overview','The atmosphere supplies air, absorbs harmful UV and traps heat. NASA holds thousands of datasets on aerosols, temperature, water vapor, rainfall and storms.'],
['Humidity','Absolute humidity is grams of vapor per cubic meter; specific is grams per kilogram of air; relative is the percent of the maximum at that temperature. It helps predict storms and fire risk.'],
['What air is made of','Air is about 78% nitrogen and 21% oxygen plus trace gases, and its mix stays nearly constant up to 50 km, except for variable water vapor.'],
['Fog','The Grand Banks off Newfoundland see over 200 foggy days a year. Fog disrupts transport but waters plants, and some regions harvest it with special nets.']]);
add('solid',[
['Solid Earth overview','The Sun, gravity, the core, ocean and atmosphere all act on the planet. Gravity, geomagnetism, tectonics and ground-motion data support disaster response.'],
['Plates and landforms','Tectonic activity builds mountains, volcanoes, plateaus and rift valleys over thousands to millions of years.'],
['Land surface','Land covers over 57 million square miles. Satellites provide surface temperature, land cover, soil moisture and fire detection.'],
['Wind-shaped landforms','Dunes and ventifacts form where wind meets loose sediment and little vegetation. Plant roots can stabilize coastal dunes.'],
['Coastal landforms','Cliffs, beaches, fjords and dunes are shaped by tides, currents, rivers and wind, and they protect inland areas from flooding.']]);

T.push({id:'sun',nav:'Sun and space',title:'The Sun and Earth',lead:'Earth gets about 10,000 times more energy from the Sun than all human power systems use. That energy drives weather, climate and the glowing skies at the poles.',cap:'Solar wind meets Earth’s magnetic field.',items:[
['Solar wind and auroras','The Sun sends charged particles to Earth. When they meet the magnetosphere, magnetic reconnection speeds them into the atmosphere and creates auroras near the poles.'],
['Solar energetic particles','When these particles connect magnetically to Earth, they ionize the upper atmosphere, create dayside auroras and can destroy ozone.'],
['Atmosphere as a shield','Earth’s atmosphere absorbs X-rays and most UV light, ionizing its own molecules and protecting life from radiation.'],
['Magnetic field','Particles moving along field lines pass through, while those crossing them are bent into circular paths by the Lorentz force, which shields living things.'],
['Albedo and energy balance','Fresh snow reflects up to 90% of sunlight, open ocean under 10%. If incoming and outgoing energy match, temperature holds steady; if not, Earth warms or cools.'],
['Sun, volcanoes and climate','Eruptions, changes in the Sun’s output and shifts in the greenhouse effect all alter Earth’s energy balance. Some studies also link cosmic rays to rainfall.']]});

T.push({id:'people',nav:'People',title:'People and the planet',lead:'More than eight billion people depend on Earth’s resources. Our cities, farms and fuels now rank among the most powerful forces shaping the planet.',cap:'Cities, farms and energy reshape ecosystems.',items:[
['Human footprint','Satellites track land turned into cities, farmland cultivation and migration. Combined with government surveys, the data reveal how human activity affects Earth.'],
['Human-influenced ecosystems','Crop maps, urban air quality and land cover surveys show how building cities, cutting forests and burning fuel change the biosphere, for better and worse.'],
['Disaster response','Nighttime lights reveal power outages after storms, and thermal anomaly data tracks wildfires moving toward populated areas.'],
['Sustainable Development Goals','The UN 2030 Agenda sets 17 goals and 169 targets, measured by 230 indicators. Solutions must balance social justice, a healthy environment and a viable economy.'],
['Greenhouse gases','Since the mid-1800s, burning fossil fuels and clearing land have raised CO2, methane and nitrous oxide. Ten of the warmest years on record have occurred since 2014.']]});
