Optional real recordings (loop-friendly MP3). Name them by section id and the site plays them instead of the synthesized sound.
Works when served over http(s), e.g. GitHub Pages:
earth.mp3 water.mp3 ice.mp3 ocean.mp3 life.mp3 air.mp3 solid.mp3 sun.mp3 people.mp3
